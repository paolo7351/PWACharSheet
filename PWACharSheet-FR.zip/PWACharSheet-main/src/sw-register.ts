import type { SWUpdateState, SWUpdateListener, SkipWaitingMessage } from './sw/types';

/**
 * Registers the service worker and manages update lifecycle.
 * Returns an API for subscribing to update state, applying updates, and dismissing prompts.
 */
export function registerServiceWorker(baseUrl: string): {
  subscribe: (listener: SWUpdateListener) => () => void;
  applyUpdate: () => Promise<void>;
  dismiss: () => void;
} {
  const listeners = new Set<SWUpdateListener>();
  let state: SWUpdateState = {
    updateAvailable: false,
    applying: false,
    error: null,
  };
  let registration: ServiceWorkerRegistration | undefined;

  function notify(): void {
    const snapshot = { ...state };
    for (const listener of listeners) {
      listener(snapshot);
    }
  }

  function setState(partial: Partial<SWUpdateState>): void {
    state = { ...state, ...partial };
    notify();
  }

  function trackInstallingWorker(worker: ServiceWorker): void {
    // If the worker has already installed by the time we start tracking, check immediately
    if (worker.state === 'installed' && navigator.serviceWorker.controller) {
      setState({ updateAvailable: true });
      return;
    }
    worker.addEventListener('statechange', () => {
      if (worker.state === 'installed' && navigator.serviceWorker.controller) {
        // A new worker installed while an existing one controls the page = update available
        setState({ updateAvailable: true });
      }
    });
  }

  function subscribe(listener: SWUpdateListener): () => void {
    listeners.add(listener);
    // Immediately notify with current state
    listener({ ...state });
    return () => {
      listeners.delete(listener);
    };
  }

  async function applyUpdate(): Promise<void> {
    const waitingWorker = registration?.waiting;
    if (!waitingWorker) {
      // The waiting worker might have been garbage collected or already activated.
      // Fall back to a hard reload.
      setState({ applying: true, error: null });
      window.location.reload();
      return;
    }

    setState({ applying: true, error: null });

    const message: SkipWaitingMessage = { type: 'SKIP_WAITING' };
    waitingWorker.postMessage(message);

    // Set up a 10-second timeout for controller change
    const timeout = new Promise<'timeout'>((resolve) =>
      setTimeout(() => resolve('timeout'), 10000),
    );

    const controllerChanged = new Promise<'changed'>((resolve) => {
      navigator.serviceWorker.addEventListener('controllerchange', () => {
        resolve('changed');
      }, { once: true });
    });

    const result = await Promise.race([timeout, controllerChanged]);

    if (result === 'timeout') {
      // Even if the SW didn't signal controller change, a reload will pick up the new version
      window.location.reload();
    } else {
      // controllerchange fired — reload the page
      window.location.reload();
    }
  }

  function dismiss(): void {
    setState({ updateAvailable: false });
  }

  // Skip registration if service worker API is not available
  if (!('serviceWorker' in navigator)) {
    return { subscribe, applyUpdate, dismiss };
  }

  // Register after the window load event
  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register(baseUrl + 'sw.js')
      .then((reg) => {
        registration = reg;

        // Check if there's already a waiting worker
        if (reg.waiting) {
          setState({ updateAvailable: true });
        }

        // Listen for new updates
        reg.addEventListener('updatefound', () => {
          const installingWorker = reg.installing;
          if (installingWorker) {
            trackInstallingWorker(installingWorker);
          }
        });

        // Periodically check for updates (every 10 minutes)
        setInterval(() => {
          reg.update().catch(() => {});
        }, 10 * 60 * 1000);

        // Also check for updates when the page becomes visible again (e.g. user switches tabs back)
        document.addEventListener('visibilitychange', () => {
          if (document.visibilityState === 'visible') {
            reg.update().catch(() => {});
          }
        });
      })
      .catch((err) => {
        // Registration failed — log and continue without caching
        console.error('Service worker registration failed:', err);
      });
  });

  // Listen for controllerchange to reload when a new SW takes over
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    // Only reload if we're not already in the middle of applying an update
    // (applyUpdate handles its own reload)
    if (!state.applying) {
      window.location.reload();
    }
  });

  return { subscribe, applyUpdate, dismiss };
}
