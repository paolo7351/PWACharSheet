import { useState } from 'react';
import type { AmmoItem } from '../../types/character';
import { Card } from '../shared/Card';
import { SectionHeader } from '../shared/SectionHeader';
import { EditableField } from '../shared/EditableField';
import { AddButton } from '../shared/AddButton';
import { EmptyState } from '../shared/EmptyState';
import { Target } from 'lucide-react';
import styles from './AmmoTracker.module.css';

interface AmmoTrackerProps {
  ammo: AmmoItem[];
  onUpdate: (index: number, field: string, value: string | number) => void;
  onAdd: () => void;
  onRemove: (index: number) => void;
  defaultCollapsed?: boolean;
}

export function AmmoTracker({ ammo, onUpdate, onAdd, onRemove, defaultCollapsed = false }: AmmoTrackerProps) {
  const [collapsed, setCollapsed] = useState(defaultCollapsed);

  return (
    <Card>
      <SectionHeader
        icon={Target}
        title="Ammunition"
        action={<AddButton label="Add" onClick={onAdd} />}
        collapsible
        collapsed={collapsed}
        onToggleCollapse={() => setCollapsed((prev) => !prev)}
      />
      {!collapsed && (
        <>
          {ammo.length === 0 && (
            // Action-oriented empty state referencing the add-ammo action
            // (ux-audit-improvements Req 12.2), using the shared EmptyState.
            <EmptyState
              icon={Target}
              heading="No ammunition tracked"
              description="Add ammunition to track quantities and firing."
              compact
              action={{ label: 'Add Ammunition', onClick: onAdd }}
            />
          )}
          <div className={styles.ammoGrid}>
            {ammo.map((a, i) => {
              const maxAmmo = a.max || a.quantity;
              return (
                <div key={i} className={styles.ammoCard}>
                  <div className={styles.ammoHeader}>
                    <EditableField
                      label=""
                      value={a.name}
                      onSave={(v) => onUpdate(i, 'name', v)}
                    />
                    <button
                      type="button"
                      onClick={() => onRemove(i)}
                      className={styles.removeBtn}
                    >
                      ✕
                    </button>
                  </div>
                  <div className={styles.ammoCount}>
                    <span
                      className={a.quantity <= 3 ? styles.ammoCountLow : styles.ammoCountNormal}
                    >
                      {a.quantity}
                    </span>
                    <span className={styles.separator}>/</span>
                    <input
                      type="number"
                      value={maxAmmo}
                      onChange={(e) => onUpdate(i, 'max', Number(e.target.value) || 0)}
                      className={styles.maxInput}
                    />
                  </div>
                  <div className={styles.btnRow}>
                    <button
                      type="button"
                      onClick={() => {
                        if (a.quantity > 0) onUpdate(i, 'quantity', a.quantity - 1);
                      }}
                      className={styles.fireBtn}
                    >
                      FIRE
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (a.quantity < maxAmmo) onUpdate(i, 'quantity', Math.min(maxAmmo, a.quantity + 1));
                      }}
                      className={styles.addOneBtn}
                    >
                      +1
                    </button>
                    <button
                      type="button"
                      onClick={() => onUpdate(i, 'quantity', maxAmmo)}
                      className={styles.refillBtn}
                    >
                      REFILL
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}
    </Card>
  );
}
