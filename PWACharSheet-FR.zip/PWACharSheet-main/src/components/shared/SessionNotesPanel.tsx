import { useState } from 'react';
import type { Character } from '../../types/character';
import { Card } from './Card';
import { EmptyState } from './EmptyState';
import { BookOpen } from 'lucide-react';
import { parseLogEntry, createLogEntry } from './sessionNotesLog';
import styles from './SessionNotesPanel.module.css';

interface SessionNotesPanelProps {
  character: Character;
  updateCharacter: (mutator: (char: Character) => Character) => void;
}

/** Format a timestamp as a human-readable date/time string */
function formatTimestamp(ts: number): string {
  const d = new Date(ts);
  return d.toLocaleString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function SessionNotesPanel({ character, updateCharacter }: SessionNotesPanelProps) {
  const [noteInput, setNoteInput] = useState('');

  const logEntries = (character.log ?? []).map((entry, index) => ({
    ...parseLogEntry(entry),
    index,
  }));

  // Sort by timestamp descending (newest first)
  const sortedEntries = [...logEntries].sort((a, b) => b.timestamp - a.timestamp);

  const handleSubmit = () => {
    const text = noteInput.trim();
    if (!text) return;

    const entry = createLogEntry(text);

    updateCharacter((char) => ({
      ...char,
      log: [entry, ...(char.log ?? [])],
    }));

    setNoteInput('');
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleDelete = (index: number) => {
    updateCharacter((char) => ({
      ...char,
      log: (char.log ?? []).filter((_, i) => i !== index),
    }));
  };

  return (
    <Card>
      <div className={styles.container}>
        {/* Add Note Form */}
        <div className={styles.addForm}>
          <textarea
            className={styles.noteInput}
            placeholder="Add a session note…"
            value={noteInput}
            onChange={(e) => setNoteInput(e.target.value)}
            onKeyDown={handleKeyDown}
            rows={1}
            aria-label="New session note"
          />
          <button
            type="button"
            className={styles.submitBtn}
            onClick={handleSubmit}
            disabled={!noteInput.trim()}
          >
            Add
          </button>
        </div>

        {/* Notes List */}
        {sortedEntries.length === 0 ? (
          <EmptyState
            icon={BookOpen}
            heading="No Session Notes"
            description="Add notes to track events, decisions, and reminders during your session."
            compact
          />
        ) : (
          <div className={styles.noteList}>
            {sortedEntries.map((entry) => (
              <div key={`${entry.index}-${entry.timestamp}`} className={styles.noteItem}>
                {entry.timestamp > 0 && (
                  <span className={styles.noteTimestamp}>
                    {formatTimestamp(entry.timestamp)}
                  </span>
                )}
                <span className={styles.noteText}>{entry.text}</span>
                <div className={styles.noteActions}>
                  <button
                    type="button"
                    className={styles.deleteBtn}
                    onClick={() => handleDelete(entry.index)}
                    aria-label="Delete note"
                  >
                    ✕ Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </Card>
  );
}
