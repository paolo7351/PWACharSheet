import { useState, useCallback } from 'react';
import type { Character, ArmourPoints, FieldPath, FieldValue } from '../../types/character';
import { useMediaQuery } from '../../hooks/useMediaQuery';
import styles from './CombatPage.module.css';

type CombatMode = 'attack' | 'defend' | 'status';
import { Picker } from '../shared/Picker';
import { Toast } from '../shared/Toast';
import { RollDialog } from '../shared/RollDialog';
import { useUndoToast } from '../../hooks/useUndoToast';
import { removeAtIndex, restoreAtIndex } from '../../logic/undo';
import { reorderArray } from '../../logic/reorder';
import { RollResultDisplay } from '../shared/RollResultDisplay';
import { FortuneResolvePanel } from '../shared/FortuneResolvePanel';
import { SpellCastingPanel } from '../shared/SpellCastingPanel';
import { EmptyState } from '../shared/EmptyState';
import { RuneManager } from '../shared/RuneManager';
import { RollHistoryPanel } from '../shared/RollHistoryPanel';
import { CollapsibleSection } from '../shared/CollapsibleSection';
import { CombatDashboard } from '../combat/CombatDashboard';
import { HouseRuleIndicator } from '../combat/HouseRuleIndicator';
import { AttackFlow } from '../combat/AttackFlow';
import { QuickRollBar } from '../combat/QuickRollBar';
import { TakeDamagePanel } from '../combat/TakeDamagePanel';
import { WeaponCards } from '../combat/WeaponCards';
import { ArmourMap } from '../combat/ArmourMap';
import { AmmoTracker } from '../combat/AmmoTracker';
import { CriticalWoundsPanel } from '../combat/CriticalWoundsPanel';
import { ConditionPicker } from '../combat/ConditionPicker';
import { HirelingCombatPanel } from '../retinue/HirelingCombatPanel';
import { ConfirmDialog } from '../shared/ConfirmDialog';
import { WEAPONS } from '../../data/weapons';
import { ARMOURS } from '../../data/armour';
import { applyCondition, removeCondition, incrementAdvantage, decrementAdvantage } from '../../logic/combat';
import { clearCombatTarget } from '../../logic/combat-target';
import { appendEvent, clearEventLog } from '../../logic/event-log';
import { TimelineView } from '../shared/TimelineView';
import { recordCriticalWound, healCriticalWound } from '../../logic/critical-wounds';
import { getBonus } from '../../logic/calculators';
import { findSkillForWeapon, RANGED_GROUPS } from '../../logic/weapons';
import { computeSkillTarget, type RollResult, type DifficultyLevel } from '../../logic/dice-roller';
import { decrementConditionDurations } from '../../logic/condition-duration';
import type { RollHistoryEntry } from '../../hooks/useRollHistory';
import type { CharacteristicKey } from '../../types/character';
import type { HitLocation } from '../combat/hitLocationTable';
import { Sword } from 'lucide-react';

// Re-exports for backward compatibility
export { RANGED_GROUPS, findSkillForWeapon } from '../../logic/weapons';

interface CombatPageProps {
  character: Character;
  characterId: string;
  update: <P extends FieldPath<Character>>(field: P, value: FieldValue<Character, P>) => void;
  updateCharacter: (mutator: (char: Character) => Character) => void;
  totalWounds: number;
  armourPoints: ArmourPoints;
  maxEncumbrance: number;
  coinWeight: number;
  rollHistory?: RollHistoryEntry[];
  addRoll?: (result: RollResult) => void;
  clearHistory?: () => void;
}



export function CombatPage({ character, characterId, update, updateCharacter, totalWounds, armourPoints, addRoll, rollHistory, clearHistory }: CombatPageProps) {
    const [showWeaponPicker, setShowWeaponPicker] = useState(false);
  const [showArmourPicker, setShowArmourPicker] = useState(false);
  const [rollDialogState, setRollDialogState] = useState<{ name: string; baseTarget: number; defaultDifficulty?: DifficultyLevel } | null>(null);
  const undoToast = useUndoToast();
  const [rollResultState, setRollResultState] = useState<RollResult | null>(null);
  const [runeManagerTarget, setRuneManagerTarget] = useState<{ type: 'weapon' | 'armour'; index: number } | null>(null);
  const [showConditionPicker, setShowConditionPicker] = useState(false);
  const [downLocation, setDownLocation] = useState<HitLocation | undefined>(undefined);
  const [combatMode, setCombatMode] = useState<CombatMode>('attack');
  // Take-Damage → critical-wound hand-off (ux-audit-improvements Req 8.2): when set,
  // the Status-mode CriticalWoundsPanel auto-opens the existing RollCriticalFlow.
  const [rollCriticalHandoff, setRollCriticalHandoff] = useState(false);
  const [expiredConditionQueue, setExpiredConditionQueue] = useState<string[]>([]);

  const isMobile = useMediaQuery('(max-width: 767px)');
  const isDesktop = useMediaQuery('(min-width: 1025px)');
  const inCombat = character.combatState.inCombat;
  const TB = getBonus(character.chars.T.i + character.chars.T.a + character.chars.T.b);

  /* ── Condition duration decrement on round advance ── */
  const handleRoundAdvanceWithDecrement = useCallback((delta: number) => {
    if (delta <= 0) {
      // Only decrement conditions when round advances forward
      update('combatState.currentRound', Math.max(0, character.combatState.currentRound + delta));
      return;
    }

    const { conditions: decremented, expiredNames } = decrementConditionDurations(character.conditions);
    updateCharacter((c) => ({
      ...c,
      conditions: decremented,
      combatState: { ...c.combatState, currentRound: c.combatState.currentRound + delta },
    }));

    if (expiredNames.length > 0) {
      setExpiredConditionQueue(expiredNames);
    }
  }, [character.conditions, character.combatState.currentRound, update, updateCharacter]);

  /* ── Expired condition prompt handlers ── */
  const handleConfirmRemoveExpired = useCallback(() => {
    const conditionName = expiredConditionQueue[0];
    updateCharacter((c) => ({
      ...c,
      conditions: c.conditions.filter((cond) => cond.name !== conditionName),
    }));
    setExpiredConditionQueue((q) => q.slice(1));
  }, [expiredConditionQueue, updateCharacter]);

  const handleDeclineRemoveExpired = useCallback(() => {
    // Keep the condition with duration "0" (already set by decrementConditionDurations)
    setExpiredConditionQueue((q) => q.slice(1));
  }, []);

  /* ── Weapon roll callback (used by WeaponCards) ── */
  const openWeaponRoll = (weapon: typeof character.weapons[number]) => {
    const skill = findSkillForWeapon(weapon, character.bSkills, character.aSkills);
    const isRanged = RANGED_GROUPS.includes(weapon.group);
    let skillName = isRanged ? `Ranged (${weapon.group})` : `Melee (${weapon.group})`;
    let baseTarget = 0;
    if (skill) {
      skillName = skill.n;
      const charVal = character.chars[skill.c as CharacteristicKey];
      if (charVal) baseTarget = computeSkillTarget(charVal.i, charVal.a, charVal.b, skill.a);
      else baseTarget = skill.a;
    }
    let defaultDifficulty: DifficultyLevel | undefined;
    if (character.combatState.engaged && isRanged && weapon.group !== 'Blackpowder') defaultDifficulty = 'Hard';
    setRollDialogState({ name: skillName, baseTarget, defaultDifficulty });
  };

  const handleRollResult = (result: RollResult) => { setRollDialogState(null); setRollResultState(result); addRoll?.(result); };

  /* ── START / END COMBAT ── */
  const startCombat = () => { update('combatState.inCombat', true); update('combatState.currentRound', 1); };
  const endCombat = () => {
    // Clear the ad-hoc Combat_Target when combat ends (ux-audit-improvements Req 1.5).
    updateCharacter((c) => {
      const cleared = clearCombatTarget(c);
      return {
        ...cleared,
        combatState: { ...cleared.combatState, inCombat: false, currentRound: 0 },
        advantage: 0,
      };
    });
  };

  /* ── Spell casting eligibility ── */
  const hasSpellcasting = character.spells.length > 0 ||
    character.talents.some(t => t.n.includes('Magic') || t.n.includes('Pray') || t.n.includes('Invoke')) ||
    character.aSkills.some(s => s.n.startsWith('Channelling') || s.n.startsWith('Language (Magick)'));

  return (
    <div className={styles.sectionGap} data-domain="combat">
      {/* ── Active house-rule indicator (read-only; ux-audit-improvements Req 11) ── */}
      <HouseRuleIndicator houseRules={character.houseRules} />

      {/* ── Segmented Control: Attack / Defend / Status (active combat only) ── */}
      {inCombat && (
        <div className={`${styles.segmentedControl} ${styles.segmentedControlSticky}`} role="tablist" aria-label="Combat mode">
          <button
            type="button"
            role="tab"
            aria-selected={combatMode === 'attack'}
            className={combatMode === 'attack' ? styles.segmentActive : styles.segment}
            onClick={() => { setRollCriticalHandoff(false); setCombatMode('attack'); }}
          >
            Attack
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={combatMode === 'defend'}
            className={combatMode === 'defend' ? styles.segmentActive : styles.segment}
            onClick={() => { setRollCriticalHandoff(false); setCombatMode('defend'); }}
          >
            Defend
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={combatMode === 'status'}
            className={combatMode === 'status' ? styles.segmentActive : styles.segment}
            onClick={() => { setRollCriticalHandoff(false); setCombatMode('status'); }}
          >
            Status
          </button>
        </div>
      )}

      {/* ── Compact sticky CombatDashboard for mobile/tablet in Attack/Defend modes ── */}
      {!isDesktop && inCombat && combatMode !== 'status' && (
        <div className={styles.compactDashboardSticky}>
          <CombatDashboard
            compact
            wCur={character.wCur} totalWounds={totalWounds} advantage={character.advantage}
            combatState={character.combatState} conditions={character.conditions}
            fortune={character.fortune} fate={character.fate} resolve={character.resolve} resilience={character.resilience}
            inCombat={inCombat}
            useGroupAdvantage={character.houseRules?.useGroupAdvantage ?? false}
            character={character}
            updateCharacter={updateCharacter}
            onUpdateWounds={(d) => {
              const newWounds = Math.max(0, Math.min(totalWounds, character.wCur + d));
              if (d < 0 && inCombat && character.advantage > 0) {
                updateCharacter((c) => ({ ...c, wCur: newWounds, advantage: 0 }));
              } else {
                update('wCur', newWounds);
              }
            }}
            onUpdateAdvantage={(d) => update('advantage', d < 0 ? decrementAdvantage(character.advantage) : d === -character.advantage ? 0 : incrementAdvantage(character.advantage, character.houseRules.advantageCap))}
            onUpdateRound={handleRoundAdvanceWithDecrement}
            onToggleEngaged={() => update('combatState.engaged', !character.combatState.engaged)}
            onRemoveCondition={(name) => updateCharacter((c) => ({ ...c, conditions: removeCondition(c.conditions, name) }))}
            onSpendFortune={() => updateCharacter((c) => ({ ...c, fortune: Math.max(0, c.fortune - 1) }))}
            onSpendResolve={() => updateCharacter((c) => ({ ...c, resolve: Math.max(0, c.resolve - 1) }))}
            onOpenConditionPicker={() => setShowConditionPicker(true)}
            onEndTurn={(result) => {
              updateCharacter((c) => {
                let newConditions = c.conditions;
                for (const name of result.removedConditions) {
                  newConditions = removeCondition(newConditions, name);
                }
                const { conditions: decremented, expiredNames } = decrementConditionDurations(newConditions);
                if (expiredNames.length > 0) {
                  setExpiredConditionQueue(expiredNames);
                }
                return {
                  ...c,
                  wCur: result.newWounds,
                  conditions: decremented,
                  combatState: { ...c.combatState, currentRound: result.roundAdvanced },
                };
              });
            }}
          />
        </div>
      )}

      {/* ── Desktop full-width CombatDashboard (single instance for all modes) ── */}
      {(isDesktop || !inCombat || combatMode === 'status') && (
        <CombatDashboard
          wCur={character.wCur} totalWounds={totalWounds} advantage={character.advantage}
          combatState={character.combatState} conditions={character.conditions}
          fortune={character.fortune} fate={character.fate} resolve={character.resolve} resilience={character.resilience}
          inCombat={inCombat}
          useGroupAdvantage={character.houseRules?.useGroupAdvantage ?? false}
          character={character}
          updateCharacter={updateCharacter}
          onUpdateWounds={(d) => {
            const newWounds = Math.max(0, Math.min(totalWounds, character.wCur + d));
            if (d < 0 && inCombat && character.advantage > 0) {
              updateCharacter((c) => ({ ...c, wCur: newWounds, advantage: 0 }));
            } else {
              update('wCur', newWounds);
            }
          }}
          onUpdateAdvantage={(d) => update('advantage', d < 0 ? decrementAdvantage(character.advantage) : d === -character.advantage ? 0 : incrementAdvantage(character.advantage, character.houseRules.advantageCap))}
          onUpdateRound={handleRoundAdvanceWithDecrement}
          onToggleEngaged={() => update('combatState.engaged', !character.combatState.engaged)}
          onRemoveCondition={(name) => updateCharacter((c) => ({ ...c, conditions: removeCondition(c.conditions, name) }))}
          onSpendFortune={() => updateCharacter((c) => ({ ...c, fortune: Math.max(0, c.fortune - 1) }))}
          onSpendResolve={() => updateCharacter((c) => ({ ...c, resolve: Math.max(0, c.resolve - 1) }))}
          onOpenConditionPicker={() => setShowConditionPicker(true)}
          onEndTurn={(result) => {
            updateCharacter((c) => {
              let newConditions = c.conditions;
              for (const name of result.removedConditions) {
                newConditions = removeCondition(newConditions, name);
              }
              const { conditions: decremented, expiredNames } = decrementConditionDurations(newConditions);
              if (expiredNames.length > 0) {
                setExpiredConditionQueue(expiredNames);
              }
              return {
                ...c,
                wCur: result.newWounds,
                conditions: decremented,
                combatState: { ...c.combatState, currentRound: result.roundAdvanced },
              };
            });
          }}
        />
      )}

      {/*
        ── Attack mode panels ──
        Kept MOUNTED while combat is active and hidden via CSS when another mode
        is selected, so AttackFlow's internal step/target state persists across
        mode switches (ux-audit-improvements Req 9.3).
      */}
      {inCombat && (
        <div className={combatMode === 'attack' ? styles.modePanel : styles.modePanelHidden} aria-hidden={combatMode !== 'attack'}>
          <CollapsibleSection title="Attack Flow" storageKey={`collapsible-attack-flow-${characterId}`} defaultExpanded={true}>
            <AttackFlow weapons={character.weapons} character={character} armourPoints={armourPoints} onRoll={(r) => addRoll?.(r)} updateCharacter={updateCharacter} onAddWeapon={() => setShowWeaponPicker(true)} />
          </CollapsibleSection>
          <CollapsibleSection title="Quick Roll" storageKey={`collapsible-quick-roll-${characterId}`} defaultExpanded={false}>
            <QuickRollBar character={character} onRoll={(r) => addRoll?.(r)} />
          </CollapsibleSection>
        </div>
      )}

      {/*
        ── Defend mode panels ──
        Kept MOUNTED while combat is active and hidden via CSS when another mode
        is selected, so TakeDamagePanel's entered values persist across mode
        switches (ux-audit-improvements Req 9.3).
      */}
      {inCombat && (
        <div className={combatMode === 'defend' ? styles.modePanel : styles.modePanelHidden} aria-hidden={combatMode !== 'defend'}>
          <CollapsibleSection title="Take Damage" storageKey={`collapsible-take-damage-${characterId}`} defaultExpanded={true}>
            <TakeDamagePanel toughnessBonus={TB} armourPoints={armourPoints} armourList={character.armour} weapons={character.weapons} wCur={character.wCur} totalWounds={totalWounds}
              useCriticalDeflection={character.houseRules?.useCriticalDeflection ?? false}
              onArmourUpdate={(updatedItem, index) => {
                updateCharacter((c) => {
                  const newArmour = [...c.armour];
                  newArmour[index] = updatedItem;
                  return { ...c, armour: newArmour };
                });
              }}
              onApplyWounds={(w) => update('wCur', Math.max(0, character.wCur - w))} min1Wound={character.houseRules.min1Wound}
              onLogDamage={(netWounds, newWCur, location) => {
                updateCharacter((c) =>
                  appendEvent(c, {
                    category: 'combat',
                    type: 'combat.damage',
                    summary: `Took ${netWounds} wound${netWounds !== 1 ? 's' : ''} to ${location} — Wounds now ${newWCur}`,
                    payload: { netWounds, newWCur, location },
                  }),
                );
              }}
              onDown={(location) => setDownLocation(location)}
              onRollCritical={(location) => {
                // Hand off to the existing critical-wound flow without navigating away
                // (ux-audit-improvements Req 8.2, 8.4). Surface it in Status mode and
                // ask the CriticalWoundsPanel to auto-open RollCriticalFlow with the
                // hit location preselected. No new critical logic is introduced here.
                setDownLocation(location);
                setRollCriticalHandoff(true);
                setCombatMode('status');
              }} />
          </CollapsibleSection>
          <CollapsibleSection title="Armour" storageKey={`combat-armour-defend-${characterId}`} defaultExpanded={true}>
            <ArmourMap armourPoints={armourPoints} armourList={character.armour}
              weapons={character.weapons}
              toughnessBonus={TB}
              onDeleteArmour={(i) => {
                const armourPiece = character.armour[i];
                updateCharacter((c) => ({ ...c, armour: removeAtIndex(c.armour, i) }));
                undoToast.show('Armour removed', armourPiece, i, (item, index) => {
                  updateCharacter((c) => ({ ...c, armour: restoreAtIndex(c.armour, item as typeof armourPiece, index) }));
                });
              }}
              onUpdateArmour={(i, field, value) => {
                updateCharacter((c) => {
                  const armour = [...c.armour];
                  armour[i] = { ...armour[i], [field]: value };
                  return { ...c, armour };
                });
              }}
              onOpenRuneManager={(i) => setRuneManagerTarget({ type: 'armour', index: i })}
              onOpenArmourPicker={() => setShowArmourPicker(true)}
              onAddCustomArmour={() => updateCharacter((c) => ({ ...c, armour: [...c.armour, { name: '', locations: '', enc: '0', ap: 0, qualities: '' }] }))} />
          </CollapsibleSection>
        </div>
      )}

      {/* ── Status mode: Fortune/Resolve and Spells ── */}
      {(!inCombat || combatMode === 'status') && (
        <>
          <CollapsibleSection title="Fortune & Resolve" storageKey={`collapsible-fortune-resolve-combat-${characterId}`} defaultExpanded={false}>
            <FortuneResolvePanel character={character} update={update} updateCharacter={updateCharacter} />
          </CollapsibleSection>

          {hasSpellcasting && <SpellCastingPanel character={character} update={update} updateCharacter={updateCharacter} addRoll={addRoll} />}
        </>
      )}

      {/* ── Weapons ── */}
      {(!inCombat || combatMode === 'attack') && (
        <>
          {character.weapons.length > 0 ? (
            <CollapsibleSection title="Weapons" storageKey={`combat-weapons-${characterId}`} defaultExpanded={true}>
              <WeaponCards weapons={character.weapons} character={character} onRollWeapon={openWeaponRoll}
                onDeleteWeapon={(i) => {
                  const weapon = character.weapons[i];
                  updateCharacter((c) => ({ ...c, weapons: removeAtIndex(c.weapons, i) }));
                  undoToast.show('Weapon removed', weapon, i, (item, index) => {
                    updateCharacter((c) => ({ ...c, weapons: restoreAtIndex(c.weapons, item as typeof weapon, index) }));
                  });
                }}
                onUpdateWeapon={(i, field, value) => {
                  updateCharacter((c) => {
                    const weapons = [...c.weapons];
                    weapons[i] = { ...weapons[i], [field]: value };
                    return { ...c, weapons };
                  });
                }}
                onReorderWeapon={(fromIndex, toIndex) => {
                  updateCharacter((c) => ({ ...c, weapons: reorderArray(c.weapons, fromIndex, toIndex) }));
                }}
                onOpenRuneManager={(i) => setRuneManagerTarget({ type: 'weapon', index: i })}
                onOpenWeaponPicker={() => setShowWeaponPicker(true)}
                onAddCustomWeapon={() => updateCharacter((c) => ({ ...c, weapons: [...c.weapons, { name: '', group: '', enc: '0', damage: '', qualities: '' }] }))} />
            </CollapsibleSection>
          ) : (
            <CollapsibleSection title="Weapons" storageKey={`combat-weapons-${characterId}`} defaultExpanded={true}>
              <EmptyState
                icon={Sword}
                heading="Add Weapon"
                compact
                action={{ label: 'Add Weapon', onClick: () => setShowWeaponPicker(true) }}
              />
            </CollapsibleSection>
          )}
        </>
      )}

      {/* ── Armour (shown when not in combat — in combat, it's in Defend mode) ── */}
      {!inCombat && (
        <CollapsibleSection title="Armour" storageKey={`combat-armour-${characterId}`} defaultExpanded={true}>
          <ArmourMap armourPoints={armourPoints} armourList={character.armour}
            weapons={character.weapons}
            toughnessBonus={TB}
            onDeleteArmour={(i) => {
              const armourPiece = character.armour[i];
              updateCharacter((c) => ({ ...c, armour: removeAtIndex(c.armour, i) }));
              undoToast.show('Armour removed', armourPiece, i, (item, index) => {
                updateCharacter((c) => ({ ...c, armour: restoreAtIndex(c.armour, item as typeof armourPiece, index) }));
              });
            }}
            onUpdateArmour={(i, field, value) => {
              updateCharacter((c) => {
                const armour = [...c.armour];
                armour[i] = { ...armour[i], [field]: value };
                return { ...c, armour };
              });
            }}
            onOpenRuneManager={(i) => setRuneManagerTarget({ type: 'armour', index: i })}
            onOpenArmourPicker={() => setShowArmourPicker(true)}
            onAddCustomArmour={() => updateCharacter((c) => ({ ...c, armour: [...c.armour, { name: '', locations: '', enc: '0', ap: 0, qualities: '' }] }))} />
        </CollapsibleSection>
      )}

      {/* ── Active Combat: Ammo, Critical Wounds, Roll History (Status mode) ── */}
      {inCombat && combatMode === 'status' && (
        <>
          {character.ammo.length > 0 && (
            <CollapsibleSection title="Ammo Tracker" storageKey={`combat-ammo-${characterId}`} defaultExpanded={!isMobile}>
              <AmmoTracker ammo={character.ammo}
                onUpdate={(i, field, value) => updateCharacter((c) => {
                  const ammo = [...c.ammo];
                  ammo[i] = { ...ammo[i], [field]: value };
                  return { ...c, ammo };
                })}
                onAdd={() => updateCharacter((c) => ({ ...c, ammo: [...c.ammo, { name: 'New Ammo', quantity: 12, max: 12, enc: '0', qualities: '' }] }))}
                onRemove={(i) => updateCharacter((c) => ({ ...c, ammo: c.ammo.filter((_, j) => j !== i) }))}
                defaultCollapsed={isMobile} />
            </CollapsibleSection>
          )}
          <CollapsibleSection title="Critical Wounds" storageKey={`combat-critical-${characterId}`} defaultExpanded={!isMobile}>
            <CriticalWoundsPanel criticalWounds={character.criticalWounds}
              onAdd={() => updateCharacter((c) => ({ ...c, criticalWounds: recordCriticalWound(c.criticalWounds, { location: 'Body', description: 'New wound', effects: '', duration: '', severity: 1, healed: false }) }))}
              onHeal={(id) => updateCharacter((c) => ({ ...c, criticalWounds: healCriticalWound(c.criticalWounds, id) }))}
              onUpdate={(i, field, value) => updateCharacter((c) => ({ ...c, criticalWounds: c.criticalWounds.map((w, j) => j === i ? { ...w, [field]: value } : w) }))}
              defaultCollapsed={isMobile}
              preselectedLocation={downLocation}
              autoOpenRollFlow={rollCriticalHandoff}
              onAddWound={(wound) => { updateCharacter((c) => ({ ...c, criticalWounds: recordCriticalWound(c.criticalWounds, wound) })); setDownLocation(undefined); setRollCriticalHandoff(false); }} />
          </CollapsibleSection>
          {rollHistory && rollHistory.length > 0 && clearHistory && (
            <CollapsibleSection title="Roll History" storageKey={`combat-history-${characterId}`} defaultExpanded={!isMobile}>
              <RollHistoryPanel history={rollHistory} onClear={clearHistory} defaultExpanded={true} />
            </CollapsibleSection>
          )}
          {/*
            ── History (unified event log) ──
            Surfaces the unified-event-log TimelineView sourced purely from
            `character.eventLog` — no separate roll store (ux-audit-improvements
            Req 13.1, 13.4). TimelineView's own category chips already allow
            filtering to `roll` and `combat` among the other categories (empty
            selection = show all), satisfying Req 13.3. Clearing mirrors App's
            pattern via `clearEventLog` through `updateCharacter` (Req 13.2).
          */}
          <CollapsibleSection title="History" storageKey={`combat-event-log-${characterId}`} defaultExpanded={!isMobile}>
            <TimelineView
              events={character.eventLog ?? []}
              onClear={() => updateCharacter((c) => clearEventLog(c))}
            />
          </CollapsibleSection>
        </>
      )}

      {/* ── Hireling Combat Panel ── */}
      {character.hirelings && character.hirelings.length > 0 && (
        <HirelingCombatPanel
          hirelings={character.hirelings}
          onUpdateWounds={(id, wCur) => updateCharacter((c) => ({
            ...c,
            hirelings: (c.hirelings || []).map((h) => h.id === id ? { ...h, wCur } : h),
          }))}
          onAddCondition={(id, condition) => updateCharacter((c) => ({
            ...c,
            hirelings: (c.hirelings || []).map((h) => h.id === id ? { ...h, conditions: [...h.conditions, condition] } : h),
          }))}
          onRemoveCondition={(id, conditionIndex) => updateCharacter((c) => ({
            ...c,
            hirelings: (c.hirelings || []).map((h) => h.id === id ? { ...h, conditions: h.conditions.filter((_, i) => i !== conditionIndex) } : h),
          }))}
        />
      )}

      {/* ── START / END COMBAT button ── */}
      <button type="button" onClick={inCombat ? endCombat : startCombat}
        className={inCombat ? styles.combatBtnEnd : styles.combatBtnStart}>
        {inCombat ? 'END COMBAT' : 'START COMBAT'}
      </button>

      {/* ── Modals ── */}
      {showConditionPicker && (
        <ConditionPicker conditions={character.conditions}
          onApply={(name) => updateCharacter((c) => ({
            ...c,
            conditions: applyCondition(c.conditions, name),
            // Core Rulebook p.164: "suffer any Conditions, you automatically lose all Advantage"
            advantage: inCombat ? 0 : c.advantage,
          }))}
          onRemove={(name) => updateCharacter((c) => ({ ...c, conditions: removeCondition(c.conditions, name) }))}
          onClose={() => setShowConditionPicker(false)} />
      )}
      {runeManagerTarget && (() => {
        const isWeapon = runeManagerTarget.type === 'weapon';
        const item = isWeapon ? character.weapons[runeManagerTarget.index] : character.armour[runeManagerTarget.index];
        if (!item) return null;
        return (
          <RuneManager itemType={runeManagerTarget.type} itemIndex={runeManagerTarget.index} itemName={item.name || 'Unnamed'}
            currentRunes={((item as { runes?: string[] }).runes) ?? []} knownRunes={character.knownRunes ?? []}
            onAddRune={(runeId) => updateCharacter((c) => {
              if (isWeapon) { const weapons = [...c.weapons]; const w = { ...weapons[runeManagerTarget.index] }; w.runes = [...(w.runes ?? []), runeId]; weapons[runeManagerTarget.index] = w; return { ...c, weapons }; }
              else { const armour = [...c.armour]; const a = { ...armour[runeManagerTarget.index] }; a.runes = [...(a.runes ?? []), runeId]; armour[runeManagerTarget.index] = a; return { ...c, armour }; }
            })}
            onRemoveRune={(runeIndex) => updateCharacter((c) => {
              if (isWeapon) { const weapons = [...c.weapons]; const w = { ...weapons[runeManagerTarget.index] }; w.runes = (w.runes ?? []).filter((_, i) => i !== runeIndex); weapons[runeManagerTarget.index] = w; return { ...c, weapons }; }
              else { const armour = [...c.armour]; const a = { ...armour[runeManagerTarget.index] }; a.runes = (a.runes ?? []).filter((_, i) => i !== runeIndex); armour[runeManagerTarget.index] = a; return { ...c, armour }; }
            })}
            onClose={() => setRuneManagerTarget(null)} />
        );
      })()}
      {showWeaponPicker && <Picker items={WEAPONS} getLabel={(w) => w.name} getGroup={(w) => w.group} onSelect={(w) => { updateCharacter((c) => ({ ...c, weapons: [...c.weapons, { ...w }] })); setShowWeaponPicker(false); }} onClose={() => setShowWeaponPicker(false)} title="Select Weapon" />}
      {showArmourPicker && <Picker items={ARMOURS} getLabel={(a) => `${a.name} (AP ${a.ap})`} onSelect={(a) => { updateCharacter((c) => ({ ...c, armour: [...c.armour, { ...a }] })); setShowArmourPicker(false); }} onClose={() => setShowArmourPicker(false)} title="Select Armour" />}
      {rollDialogState && <RollDialog skillOrCharName={rollDialogState.name} baseTarget={rollDialogState.baseTarget} defaultDifficulty={rollDialogState.defaultDifficulty} onRoll={handleRollResult} onClose={() => setRollDialogState(null)} />}
      {rollResultState && <RollResultDisplay result={rollResultState} onClose={() => setRollResultState(null)} />}
      <Toast
        message={undoToast.pending?.message ?? null}
        duration={5000}
        action={undoToast.pending ? { label: 'Undo', onAction: undoToast.undo } : undefined}
      />
      {/* ── Expired Condition Prompt ── */}
      {expiredConditionQueue.length > 0 && (
        <ConfirmDialog
          message={`Remove ${expiredConditionQueue[0]}? Its duration has expired.`}
          onConfirm={handleConfirmRemoveExpired}
          onCancel={handleDeclineRemoveExpired}
          confirmLabel="Remove"
          cancelLabel="Keep"
        />
      )}
    </div>
  );
}

export default CombatPage;
