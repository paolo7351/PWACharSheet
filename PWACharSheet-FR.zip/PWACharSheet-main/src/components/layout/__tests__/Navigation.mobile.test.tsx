import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import { Navigation } from '../Navigation';
import { CommandPaletteProvider } from '../../command-palette/CommandPaletteContext';

/**
 * Mobile Navigation Tests
 * **Validates: Requirements 1.1, 1.2, 1.3, 2.1**
 *
 * Tests verify that the Navigation component applies correct mobile
 * optimizations for touch targets, icon sizing, label sizing, and fixed height.
 */

// Mock matchMedia for mobile viewport (max-width: 767px matches)
function mockMobileViewport() {
  Object.defineProperty(window, 'innerWidth', { value: 375, writable: true });
  Object.defineProperty(window, 'innerHeight', { value: 667, writable: true });

  window.matchMedia = vi.fn().mockImplementation((query: string) => ({
    matches: query.includes('max-width: 767px'),
    media: query,
    onchange: null,
    addListener: vi.fn(),
    removeListener: vi.fn(),
    addEventListener: vi.fn(),
    removeEventListener: vi.fn(),
    dispatchEvent: vi.fn(),
  }));
}

describe('Navigation mobile touch targets and height', () => {
  beforeEach(() => {
    mockMobileViewport();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  const renderWithProvider = (ui: React.ReactElement) =>
    render(<CommandPaletteProvider>{ui}</CommandPaletteProvider>);

  it('renders the navigation bar as a nav element with correct landmark', () => {
    renderWithProvider(<Navigation activePage="character" onPageChange={vi.fn()} />);

    const nav = screen.getByRole('navigation', { name: /main navigation/i });
    expect(nav).toBeInTheDocument();
  });

  it('applies the sidebar class which sets fixed height of 64px on mobile (Req 2.1)', () => {
    renderWithProvider(<Navigation activePage="character" onPageChange={vi.fn()} />);

    const nav = screen.getByRole('navigation', { name: /main navigation/i });
    // The nav element uses the sidebar class which has --nav-height-mobile: 64px in mobile media query
    expect(nav).toBeInTheDocument();
    expect(nav.className).toContain('sidebar');
  });

  it('renders all nav items plus Search in scrollable row on mobile', () => {
    renderWithProvider(<Navigation activePage="character" onPageChange={vi.fn()} />);

    const navButtons = screen.getAllByRole('button').filter(
      (btn) => btn.getAttribute('data-section') !== null
    );
    // 7 nav items (Character, Combat, Retinue, Estate, Endeavours,
    // Advancement, Settings) + Search + Keyboard shortcuts affordance (Req 14.2) = 9
    expect(navButtons).toHaveLength(9);

    // The core affordances are all present in the scrollable row.
    expect(screen.getByRole('button', { name: /search game reference/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /keyboard shortcuts/i })).toBeInTheDocument();
  });

  it('nav items have min-height for 48px touch targets via CSS class (Req 1.1)', () => {
    renderWithProvider(<Navigation activePage="character" onPageChange={vi.fn()} />);

    const navButtons = screen.getAllByRole('button').filter(
      (btn) => btn.getAttribute('data-section') !== null
    );

    // Each nav button should use navItem or navItemActive class which applies
    // min-height: var(--mobile-touch-lg, 48px) in the mobile media query
    navButtons.forEach((btn) => {
      expect(
        btn.className.includes('navItem') || btn.className.includes('navItemActive')
      ).toBe(true);
    });
  });

  it('renders icons as SVG elements with minimum 22px sizing (Req 1.2)', () => {
    renderWithProvider(<Navigation activePage="character" onPageChange={vi.fn()} />);

    const navButtons = screen.getAllByRole('button').filter(
      (btn) => btn.getAttribute('data-section') !== null
    );

    navButtons.forEach((btn) => {
      const svg = btn.querySelector('svg');
      expect(svg).not.toBeNull();
      // Lucide icons are rendered with size prop; CSS mobile override sets min-width/min-height: 22px
      // The component renders icons with size={18} but CSS overrides ensure minimum 22px on mobile
      expect(svg).toBeInTheDocument();
    });
  });

  it('renders label text in span elements for each visible nav item (Req 1.3)', () => {
    renderWithProvider(<Navigation activePage="character" onPageChange={vi.fn()} />);

    // Mobile scrollable bar shows all nav items + Search
    const expectedLabels = ['Character', 'Combat', 'Retinue', 'Estate', 'Endeavours', 'Advancement', 'Settings', 'Search'];

    expectedLabels.forEach((label) => {
      const labelElement = screen.getByText(label);
      expect(labelElement).toBeInTheDocument();
      expect(labelElement.tagName).toBe('SPAN');
    });
  });

  it('active nav item uses navItemActive class with top border accent (Req 1.4)', () => {
    renderWithProvider(<Navigation activePage="combat" onPageChange={vi.fn()} />);

    const activeButton = screen.getByRole('button', { name: /combat/i });
    expect(activeButton).toHaveAttribute('aria-current', 'page');
    // navItemActive class in mobile CSS applies border-top: 3px solid var(--accent-gold)
    expect(activeButton.className).toContain('navItemActive');
  });

  it('inactive nav items use navItem class (no active border)', () => {
    renderWithProvider(<Navigation activePage="combat" onPageChange={vi.fn()} />);

    const characterButton = screen.getByText('Character').closest('button');
    expect(characterButton).not.toBeNull();
    expect(characterButton!.className).toContain('navItem');
    expect(characterButton!.className).not.toContain('navItemActive');
  });

  it('does not render app title and character name elements on mobile (hidden via conditional rendering)', () => {
    renderWithProvider(
      <Navigation
        activePage="character"
        onPageChange={vi.fn()}
        characterName="Brunhilde"
      />
    );

    // On mobile, appTitle and charName are not rendered (conditional rendering via isMobile)
    const nav = screen.getByRole('navigation', { name: /main navigation/i });
    const appTitle = nav.querySelector('[class*="appTitle"]');
    const charName = nav.querySelector('[class*="charName"]');
    expect(appTitle).not.toBeInTheDocument();
    expect(charName).not.toBeInTheDocument();
  });
});
